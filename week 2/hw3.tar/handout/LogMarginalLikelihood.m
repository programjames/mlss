function [logml] = LogMarginalLikelihood (XTrain, yTrain, gamma, sigma,h)
  logml = 1;
endfunction
