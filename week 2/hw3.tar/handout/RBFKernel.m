function K =RBFKernel(X1, X2, sigma, h)
  % Can you do this without for loops? 
  K = zeros(size(X1,1),size(X2,1));
end

